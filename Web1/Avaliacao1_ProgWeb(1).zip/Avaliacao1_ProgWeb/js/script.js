// Executa após o DOM carregar
document.addEventListener('DOMContentLoaded', function () {

    atualizarAreaUsuario();

    // ===== LOGIN =====
    const btnAutenticar = document.getElementById('btn-autenticar');
    if (btnAutenticar) {
        btnAutenticar.addEventListener('click', autenticar);
    }

    // ===== CADASTRO =====
    const formCadastro = document.getElementById('cadastro-form');
    if (formCadastro) {
        formCadastro.addEventListener('submit', function (e) {
            e.preventDefault();
            alert('Cadastro realizado com sucesso!');
            formCadastro.reset();
            formCadastro.classList.remove('custom');
            document.querySelector('input[name="estilo"][value="default"]').checked = true;
        });

        // Alternância de estilo default/custom
        const radiosEstilo = document.querySelectorAll('input[name="estilo"]');
        radiosEstilo.forEach(function (radio) {
            radio.addEventListener('change', function () {
                if (this.value === 'custom') {
                    formCadastro.classList.add('custom');
                } else {
                    formCadastro.classList.remove('custom');
                }
            });
        });
    }
});

// Atualiza o cabeçalho conforme estado de autenticação
function atualizarAreaUsuario() {
    const userArea = document.getElementById('user-area');
    if (!userArea) return;

    const autenticado = localStorage.getItem('autenticado') === 'true';
    const login = localStorage.getItem('login');

    if (autenticado && login) {
        userArea.innerHTML =
            '<a href="cadastro.html" title="Cadastro de usuário">' +
                '<img src="https://i.pravatar.cc/80?img=12" alt="Foto do usuário">' +
                '<span>' + login + '</span>' +
            '</a>' +
            '<button id="btn-logout" style="margin-left:10px;background:#dc2626;color:#fff;border:none;padding:6px 12px;border-radius:4px;cursor:pointer;">Sair</button>';

        document.getElementById('btn-logout').addEventListener('click', logout);
    } else {
        userArea.innerHTML = '<span>Usuário não autenticado</span>';
    }
}

// Autenticar usuário
function autenticar() {
    const login = document.getElementById('login').value.trim();
    const senha = document.getElementById('senha').value.trim();
    const msg = document.getElementById('login-msg');

    if (login === '' || senha === '') {
        msg.textContent = 'Preencha os campos Login e Senha para continuar.';
        return;
    }

    localStorage.setItem('login', login);
    localStorage.setItem('autenticado', 'true');

    window.location.href = 'index.html';
}

// Logout
function logout() {
    localStorage.removeItem('login');
    localStorage.removeItem('autenticado');
    atualizarAreaUsuario();
}
