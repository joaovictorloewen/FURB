# Avaliação 1 - Programação Web I

**Tema:** TechEdu - Escola de Tecnologia

**Integrantes:**
- Joao Victor Loewen
- Lucas Shimazaki Batistti

## Estrutura
```
Avaliacao1_ProgWeb/
├── index.html       (página inicial)
├── login.html       (autenticação)
├── cadastro.html    (cadastro de usuário)
├── css/style.css    (estilos)
└── js/script.js     (lógica e localStorage)
```

## Como usar
1. Abra `index.html` no navegador.
2. Clique em **LOGIN** no menu para autenticar.
3. Após login, clique na foto do usuário (canto superior direito) para acessar o cadastro.
4. Na página de cadastro, alterne entre **Default** e **Custom** para mudar o estilo do formulário.

## Requisitos atendidos
- Cabeçalho, menu, área principal e rodapé em todas as páginas
- Cabeçalho e rodapé fixos
- Logo clicável retorna à página inicial
- Menu com itens e sub-itens
- Item LOGIN ativo apontando para login.html
- Validação dos campos no login (não autentica vazio)
- localStorage com login e flag de autenticação
- Área do usuário no canto direito (não autenticado / foto + login)
- Foto do usuário linka para página de cadastro
- Formulário com 6 campos e 3+ tipos diferentes (text, email, date, radio, select, checkbox)
- Switcher default/custom alterando font-family dos labels e background dos inputs
- CSS e JS em arquivos separados, referenciados no `<head>`
- Páginas responsivas (media queries)
- Nomes dos integrantes no rodapé
